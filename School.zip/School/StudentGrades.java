package School;
import java.util.Scanner;

public class StudentGrades {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter student's name");
		String name = scan.next();
		System.out.println("Enter student's grades for Exam1 , Exam2 , Midterm , Final");
		float[] grades = new float[4];
		for(int i = 0 ; i<4 ; i++) {
			grades[i] = scan.nextFloat();;
		}
		
		float av = 0;
		for (int i=0 ; i< grades.length ; i++){
			av += grades[i];
		}
		av = av/ grades.length;
		System.out.println(name + "'s average is " + av);
		
		float highest = 0;
		for (int i=0 ; i< grades.length ; i++){
			if (grades[i] > highest){
				highest = grades[i];
			}
		}
		System.out.println("Highest grade: " + highest);
		
		float low = 100;
		for (int i=0 ; i< grades.length ; i++){
			if (grades[i] < low){
				low = grades[i];
			}
	}
		System.out.println("Lowest grade: " + low);
		
		String lettergrade;
		if (av < 60) lettergrade = "F";
		else if (av>= 60 && av< 63) lettergrade = "D";
		else if (av>= 63 && av< 67) lettergrade = "D+";
		else if (av>= 67 && av< 70) lettergrade = "C-";
		else if (av>= 70 && av< 73) lettergrade = "C";
		else if (av>= 73 && av< 77) lettergrade = "C+";
		else if (av>= 77 && av< 80) lettergrade = "B-";
		else if (av>= 80 && av< 83) lettergrade = "B";
		else if (av>= 83 && av< 87) lettergrade = "B+";
		else if (av>= 87 && av< 90) lettergrade = "A-";
		else {
			lettergrade = "A";
		}
		System.out.println("Letter Grade: " + lettergrade);
	}
	
	

	

}
