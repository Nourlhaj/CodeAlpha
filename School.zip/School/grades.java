package School;

import java.util.Arrays;

public class grades {
	private String name;
	private float[] grades;
	private float average;
	private float highest;
	private float lowest;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float[] getGrades() {
		return grades;
	}
	public void setGrades(float[] grades) {
		this.grades = grades;
	}
	public float getAverage() {
		float av = 0;
		for (int i=0 ; i< grades.length ; i++){
			av += grades[i];
		}
		av = av/ grades.length;
		return av;
	}
	
	public void setAverage(float average) {
		this.average = average;
	}
	public float getHighest() {
		float highest = 0;
		for (int i=0 ; i< grades.length ; i++){
			if (grades[i] > highest){
				highest = grades[i];
			}
		}
		return highest;
	}
	public void setHighest(float highest) {
		this.highest = highest;
	}
	public float getLowest() {
		float low = 100;
		for (int i=0 ; i< grades.length ; i++){
			if (grades[i] < low){
				highest = grades[i];
			}
		}
		return low;
	}
	public void setLowest(float lowest) {
		this.lowest = lowest;
	}
	
	@Override
	public String toString() {
		return "grades [name=" + name + ", grades=" + Arrays.toString(grades) + ", average=" + average + ", highest="
				+ highest + ", lowest=" + lowest + "]";
	}
	
	

	
	
}
