package Trading;

import java.util.Scanner;

public class StockTradingPlatform {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Market market = new Market();
        Portfolio portfolio = new Portfolio(10000); // Starting balance

        boolean running = true;
        while (running) {
            System.out.println("\n--- Menu ---");
            System.out.println("1. View Market Data");
            System.out.println("2. Buy Stock");
            System.out.println("3. Sell Stock");
            System.out.println("4. View Portfolio");
            System.out.println("5. View Portfolio Value");
            System.out.println("6. Exit");
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    market.updatePrices();
                    market.displayMarketData();
                    break;
                case 2:
                    System.out.print("Enter stock symbol to buy: ");
                    String buySymbol = scanner.next();
                    System.out.print("Enter quantity: ");
                    int buyQuantity = scanner.nextInt();
                    Stock stockToBuy = market.getStockBySymbol(buySymbol);
                    if (stockToBuy != null) {
                        portfolio.buyStock(stockToBuy, buyQuantity);
                    } else {
                        System.out.println("Stock not found.");
                    }
                    break;
                case 3:
                    System.out.print("Enter stock symbol to sell: ");
                    String sellSymbol = scanner.next();
                    System.out.print("Enter quantity: ");
                    int sellQuantity = scanner.nextInt();
                    Stock stockToSell = market.getStockBySymbol(sellSymbol);
                    if (stockToSell != null) {
                        portfolio.sellStock(stockToSell, sellQuantity);
                    } else {
                        System.out.println("Stock not found.");
                    }
                    break;
                case 4:
                    portfolio.viewPortfolio();
                    break;
                case 5:
                    double totalValue = portfolio.calculateTotalValue();
                    System.out.println("Total Portfolio Value: $" + String.format("%.2f", totalValue));
                    break;
                case 6:
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        scanner.close();
    }
}