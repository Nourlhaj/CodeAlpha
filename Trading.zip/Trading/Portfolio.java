package Trading;
import java.util.HashMap;


public class Portfolio {
    private HashMap<Stock, Integer> stocks; // Stock and its quantity
    private double balance;

    public Portfolio(double initialBalance) {
        this.stocks = new HashMap<>();
        this.balance = initialBalance;
    }

    public double getBalance() {
        return balance;
    }

    public void buyStock(Stock stock, int quantity) {
        double totalCost = stock.getPrice() * quantity;
        if (balance >= totalCost) {
            stocks.put(stock, stocks.getOrDefault(stock, 0) + quantity);
            balance -= totalCost;
            System.out.println("Bought " + quantity + " shares of " + stock.getSymbol());
        } else {
            System.out.println("Insufficient funds to buy " + quantity + " shares of " + stock.getSymbol());
        }
    }

    public void sellStock(Stock stock, int quantity) {
        if (stocks.containsKey(stock) && stocks.get(stock) >= quantity) {
            stocks.put(stock, stocks.get(stock) - quantity);
            balance += stock.getPrice() * quantity;
            System.out.println("Sold " + quantity + " shares of " + stock.getSymbol());
        } else {
            System.out.println("You don't own enough shares of " + stock.getSymbol());
        }
    }

    public void viewPortfolio() {
        System.out.println("\n--- Portfolio ---");
        for (Stock stock : stocks.keySet()) {
            int quantity = stocks.get(stock);
            if (quantity > 0) {
                System.out.println(stock + " - Shares: " + quantity);
            }
        }
        System.out.println("Cash Balance: $" + String.format("%.2f", balance));
    }

    public double calculateTotalValue() {
        double totalValue = balance;
        for (Stock stock : stocks.keySet()) {
            int quantity = stocks.get(stock);
            totalValue += stock.getPrice() * quantity;
        }
        return totalValue;
    }
}