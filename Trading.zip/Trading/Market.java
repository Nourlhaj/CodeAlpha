package Trading;

import java.util.ArrayList;
import java.util.Random;

public class Market {
    private ArrayList<Stock> stocks;

    public Market() {
        stocks = new ArrayList<>();
        initializeStocks();
    }

    private void initializeStocks() {
        stocks.add(new Stock("Apple", "AAPL", 150.0));
        stocks.add(new Stock("Tesla", "TSLA", 700.0));
        stocks.add(new Stock("Amazon", "AMZN", 3500.0));
        stocks.add(new Stock("Google", "GOOG", 2800.0));
    }

    public void updatePrices() {
        Random rand = new Random();
        for (Stock stock : stocks) {
            double percentageChange = (rand.nextDouble() - 0.5) * 0.1; // Change between -5% and +5%
            stock.setPrice(stock.getPrice() * (1 + percentageChange));
        }
    }

    public void displayMarketData() {
        System.out.println("\n--- Market Data ---");
        for (Stock stock : stocks) {
            System.out.println(stock);
        }
    }

    public Stock getStockBySymbol(String symbol) {
        for (Stock stock : stocks) {
            if (stock.getSymbol().equalsIgnoreCase(symbol)) {
                return stock;
            }
        }
        return null; // Return null if stock is not found
    }
}