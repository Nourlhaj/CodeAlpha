package HOTEL;

public class DeluxeRoom extends Room{

	@Override
	public String roomType() {
		return "Deluxe Room";
	}
	
	public DeluxeRoom() {
		
	}

}
