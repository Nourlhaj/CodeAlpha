package HOTEL;

public class Guest extends Person {
	private int nextguestID;
	private final int ID;
	

	
	
	public Guest(String name , int age) {
		super( name , age);
		this.ID = nextguestID;
		this.nextguestID = nextguestID + 1;
	}

	public Guest(Guest other) {
		this.nextguestID = other.nextguestID;
		this.ID = other.ID;
	}


	public int getID() {
		return ID;
	}

	@Override
	public String toString() {
		return "Guest name: " + name +"age: " + age + ", ID=" + ID ;
	}
	
	
}
