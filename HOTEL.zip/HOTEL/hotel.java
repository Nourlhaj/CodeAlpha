package HOTEL;
import java.time.LocalDate;


public class hotel implements Manageable{
	private Booking bookings[];
	private Room[] rooms;
	private final int deluxeRoomCount;
	private int bookingCount;
	
	
	
	public hotel(Room[] rooms) {
		this.rooms = rooms;
		int roomslength = rooms.length;
		Booking bookings[] = new Booking[roomslength];
		int deluxecount = 0;
		for (int i = 0 ; i < roomslength ; i++) {
			if (rooms[i].roomType() == "Deluxe Room" ) deluxecount += 1;
		}
		deluxeRoomCount = deluxecount;
	}
	
	public Booking[] getBookings() {
		return bookings;
	}

	public Room[] getRooms() {
		return rooms;
	}

	@Override
	public boolean add(Object item) {
		if (! (item instanceof Booking)) {
			System.out.println("Not valid");
			return false;}
			
			Room bookingroom = (Room) item;
	        Room bookedRoom = null;
	        for (Room room : rooms) {
	            if (room.getRoomNumber() == bookingroom.getRoomNumber() ) {
	                bookedRoom = room;
	                break;
	            }
	        }
		
	
	if (bookedRoom == null) {
        System.out.println("There is no room in this hotel with room number " + bookingroom.getRoomNumber() + "!");
        return false;
    }
	else {
		return true;
	}
	
		}
	
	
	
	@Override
	public Object getdetails(int id) {
		for (Room room : rooms) {
			if (room.getRoomNumber() == id) {
				return room.roomType();
			}
		}
		return null;
		
	}
	
	public String toString() {
		int c = 0;
		for (Room room : rooms) {
			if (room.roomType() == "Deluxe Room")
				c += 1;		
		}
		return "The hotel has " + rooms.length + "rooms (" + c + "are Deluxe Rooms)";
		
	}
	
}
