package HOTEL;

public abstract class Room {
		private static int nextRoomID = 100;
		private final int roomNumber;
		
		
		
		public Room() {
			this.roomNumber = nextRoomID;
			nextRoomID += 1 ;
		}



		public int getRoomNumber() {
			return roomNumber;
		}
		
		public abstract String roomType();
		
		
		public String toString() {
			return "Room ( " + roomType() + ")";
		}
		
	}


