package HOTEL;
import java.time.LocalDate;
import java.util.*;

public class Booking {
	private final Guest guest;
	private final Room room;
	private final LocalDate InDate;
	private final LocalDate OutDate;
	public Guest getGuest() {
		return guest;
	}
	public Room getRoom() {
		return room;
	}
	public LocalDate getInDate() {
		return InDate;
	}
	public LocalDate getOutDate() {
		return OutDate;
	}
	
	public Booking(Guest guest, Room room, LocalDate InDate, LocalDate OutDate) {
		this.InDate = InDate;
		this.OutDate = OutDate;
		assert OutDate.isAfter(InDate): "Check-out Date "+ OutDate +
		"should be after Check-in Date " + InDate + " !";
		this.guest = guest;
		this.room = room;
		
	}
	
	
	
}
