package HOTEL;

public class StandardRoom extends Room{

	@Override
	public String roomType() {
		return "Standard Room";
	}

	
}
