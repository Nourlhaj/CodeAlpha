package HOTEL;

public interface Manageable {
	boolean add(Object item);
	Object getdetails(int id);
}
