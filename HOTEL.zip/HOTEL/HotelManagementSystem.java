package HOTEL;

import java.time.LocalDate;

public class HotelManagementSystem {
	public static void main(String[] args) {
		Room[] rooms = new Room[6];
		
		rooms[0] = new StandardRoom();
		rooms[2] = new StandardRoom();
		rooms[4] = new StandardRoom();
		rooms[1] = new DeluxeRoom();
		rooms[3] = new DeluxeRoom();
		rooms[5] = new DeluxeRoom();
		hotel H = new hotel(rooms);
		Guest G1 = new Guest("nour",20);
		Guest G2 = new Guest("imad", 19);
		Booking B1 = new Booking(G1, rooms[0], LocalDate.now(), LocalDate.now().plusDays(2));
		Booking B2 = new Booking(G2, rooms[1], LocalDate.now().plusDays(1), LocalDate.now().plusDays(3));
		Guest G3 = new Guest("Jad",21);
		
		Booking B3 = new Booking(G3, rooms[0], LocalDate.now(), LocalDate.now().plusDays(2));
		
	}
}
