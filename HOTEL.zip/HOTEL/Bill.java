package HOTEL;

public class Bill implements Manageable {
	private double billAmount;
	private boolean VATAdded;
	
	public void Bill(double billAmount) {
		this.billAmount = billAmount;
		this.VATAdded = false;
	}

	@Override
	public boolean add(Object item) {

	
		boolean isdouble = item instanceof Double;
		if ( ! (isdouble)) {
			return false;}
		else {
			if (VATAdded== true) return false;
		
		else {
			double vatRate = (double) item;
		
			billAmount += this.billAmount*vatRate;
			return true;
		}
		}
	}

	@Override
	public Object getdetails(int id) {
		return "Final Bill Amount with VAT: " + billAmount;
	}
	
}
